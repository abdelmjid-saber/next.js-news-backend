<div {{ $attributes->class('text-sm text-gray-600') }}>
    {{ $slot }}
</div>
