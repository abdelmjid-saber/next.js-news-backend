<div class="max-w-7xl mx-auto sm:px-6 lg:px-8 py-4 bg-white dark:bg-gray-800 rounded-lg outline outline-1 outline-gray-300 dark:outline-gray-800 shadow-md p-7">
    {{ $slot }}
</div>